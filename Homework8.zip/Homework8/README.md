# DouDemo
[![Badge](https://img.shields.io/badge/link-996.icu-red.svg)](https://996.icu/#/zh_CN)
### 仿抖音部分功能
* [【Android 进阶】仿抖音系列之翻页上下滑切换视频（一）](https://www.jianshu.com/p/2c71f699c5c4)
垂直滑动的viewpager 实现仿抖音视频切换
* [【Android 进阶】仿抖音系列之列表播放视频（二）](https://www.jianshu.com/p/ee6b7c200c9c)
仿抖音列表播放视频
* [【Android 进阶】仿抖音系列之列表播放视频（三）](https://www.jianshu.com/p/15a70f242c4d)
列表视频的优化，视频缓存的使用
* [【Android 进阶】仿抖音系列之翻页上下滑切换视频（四）](https://www.jianshu.com/p/e0bd595d6321)
PagerSnapHelper+RecyclerView 实现仿抖音视频切换
* [【Android 进阶】仿抖音系列之视频预览和录制（五）](https://www.jianshu.com/p/dc63d77b6761)
SurfaceView实现相机预览，MediaRecorder实现视频录制及保存


### 关于
* 关于下载慢的问题，已去除腾讯播放器代码，项目降低到167kb.
