package com.ch.doudemo.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.ch.doudemo.R;

public class ChooseModeActivity extends AppCompatActivity {
//    private Button btn_PhonePhoto;
//    private Button btn_PhoneVideo;
    private Button btn_MyCamera;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choosemode);
//        btn_PhonePhoto = findViewById(R.id.btn_choosePhonePhoto);
//        btn_PhoneVideo = findViewById(R.id.btn_choosePhoneVideo);
        btn_MyCamera = findViewById(R.id.btn_chooseMyCamera);
        btn_MyCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ChooseModeActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
//        btn_PhoneVideo.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(ChooseModeActivity.this, PhoneVideoActivity.class);
//                startActivity(intent);
//            }
//        });
    }
}
